<?php echo e($slot); ?>

<?php /**PATH D:\Laravel Framework\Authentication\laravel-auth\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
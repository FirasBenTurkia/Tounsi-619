<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Laravel Framework\Authentication\laravel-auth\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>
<script type="text/javascript">
    $(document).ready(function(){
        var is_touch_device = 'ontouchstart' in document.documentElement;
        if (!is_touch_device) {
            $('[data-toggle="tooltip"]').tooltip();
        }
    });
</script>
<?php /**PATH D:\Laravel Framework\Authentication\laravel-auth\vendor\jeremykenedy\laravel-roles\src/resources/views//laravelroles/scripts/tooltips.blade.php ENDPATH**/ ?>